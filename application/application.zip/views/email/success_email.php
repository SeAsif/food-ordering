    Hi <?=$firstName?>,
	
	Your order at <?=$restaurantName?> for  <?=$date?> has been submitted to the restaurant and will be prepared by <?=$deliveryTime?>.
	
	Your order confirmation number is <?=$orderNumber?>. Please keep this with you at the time of pick-up
	
	Thanks,
	
	Starvved Team.
    Hi , 
    	
	Your order cannot be placed due to validation failuer. Please reconfirm.
	
	Thanks,
	
	Starvved Team.
	Hi <?=$arrInfo["firstname"]?>,
	
	Your account has successfully been created on http://www.starvved.com
	
	Your login credentials are given below:
	
	Email:<?=$arrInfo["email"]?>
	
	Password:<?=$password?>
	
	Thanks,
	
	Starvved Team.				
				
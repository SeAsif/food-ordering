<?
$this->load->view("userfront/header_view");
echo form_open(base_url().'home/recoverview/',$arrUser->id.'/',$arrUser->security_code);
?>

<!-- Start Mid Right -->

<div class="cont-wrap">
        	<div class="cont-round"><img src="<?=base_url()?>images/front/rest-top.jpg" alt="top" border="0" /></div>
        	<div class="rest-mid">

            <!-- Start Restaurant Account Settings Head -->
				<div class="account-hed">
                	<h1>Create Account<br /></h1>
                </div>
            <!-- End Restaurant Account Settings Head -->
				<br class="clear" />
            
            <!-- Start Update Account Form Section -->
				<div class="account-form">


					<?
                         if(isset($errors))  	
                         {
                           if (isset($errors) && count($errors) > 0)
                           {
                           ?>
                    <div class="ui-widget">
                    <div class="ui-state-error ui-corner-all" style="padding: 0 .7em;">                                               
                           <?
                               foreach ($errors as $error)
                               {
                                echo $error;
                               }
                            ?>
                    </div>
                    </div>
                            <?
                           }
                         } 
                        ?>
                    
                    
                   
               
                    <?
                         if(isset($successes))  	
                         {
                           if (count($successes) > 0)
                           {
                           ?>
                    <div class="ui-widget">
                     <div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;"> 
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>                                               
                           <?
                               foreach ($successes as $success)
                               {
                                echo $success;
                               }
							   ?>&nbsp;&nbsp;
                               <a href="http://www.starvved.com">Click Here</a> 
							  <? echo " to go to log in page";
                            ?>
                    </div>
                    </div>
                            <?
                           }
                         } 
                        ?>



					<?
					if(count($successes) == 0)
					{
                        echo form_open(base_url().'home/recoverview/',$arrUser->id.'/',$arrUser->security_code);
                    ?>
                            <table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="table"s>
                                  <tr>
                                    <td valign="top"></td>
                                  </tr>
                                  <tr>
                                    <td valign="top" style="padding-top:30px;">
                                    
                                    <div class="login-page-wrap">
                                    <TABLE WIDTH=476 BORDER=0 align="center" CELLPADDING=0 CELLSPACING=0 >
                                      <TR>
                                        <TD COLSPAN=4 WIDTH=272 HEIGHT=42 ></TD>
                                      </TR>
                                      <TR>
                                        <TD style="width:30%;"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                                          <tr>
                                            <td valign="middle" style="padding-bottom:0px;">Password:</td>
                                          </tr>
                                        </table></TD>
                                        <TD WIDTH=125 HEIGHT=21 COLSPAN=2 >
                                            <input name="password" type="password" class="txt-field" size="17" value="">
                                            <input type="hidden" name="userid" id="userid" value="<?=$arrUser["id"]?>">
                                            <input type="hidden" name="codeid" id="codeid" value="<?=$arrUser["security_code"]?>">
                                        </TD>
                                        <TD WIDTH=36 HEIGHT=21 ></TD>
                                      </TR>
                                      <TR>
                                        <TD COLSPAN=4 WIDTH=272 HEIGHT=8 > </TD>
                                      </TR>
                                      <TR>
                                        <TD WIDTH=111 HEIGHT=21 ><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                                          <tr>
                                            <td style="padding-bottom:0px;">Confirm Password:</td>
                                          </tr>
                                        </table></TD>
                                        <TD WIDTH=125 HEIGHT=21 COLSPAN=2 >
                                        <input name="confpass" type="password" class="txt-field" size="17" value="">
                                        </TD>
                                        <TD WIDTH=36 HEIGHT=21 ></TD>
                                      </TR>
                                      <TR>
                                        <TD> 
                                     </TD>
                                        
                                        <TD WIDTH=36 HEIGHT=21 ><input type="submit" name="Submit" class="btn" value="Submit" style="float:left; margin-top:5px;" ></TD>
                                      </TR>
                                      <TR>
                                        <TD COLSPAN=4 WIDTH=272 HEIGHT=42  class="err" align="center">
                                            <?
                                         if(isset($errors))  	
                                         {
                                           if (isset($errors) && count($errors) > 0)
                                           {
                                               foreach ($errors as $error)
                                               {
                                                echo $error;
                                               }
                                           }
                                         } 
                                            ?>
                                        </TD>
                                      </TR>
                                    </TABLE>
                                    </div>
                                    
                                    </td>
                                  </tr>
                                </table></td>
                              </tr>
                            </table>
                    <!-- End Mid Right -->
                    </form>
                 <?
				 }
				 ?>   
                </div>
			
            <!-- End Update Account Form Section -->

            </div>
        	<div class="cont-round"><img src="<?=base_url()?>images/front/rest-bottom.jpg" alt="top" border="0" /></div>
        </div>

<?
$this->load->view("userfront/footer_view");
?>
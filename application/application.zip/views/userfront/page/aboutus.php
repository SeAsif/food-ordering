<?
$this->load->view("userfront/header_view");
?>

<!-- Start Menu Popups -->

<script language="javascript">
var url	=	'<?=base_url()?>userrestaurant/addtocart/';
function refreshItemPage()
{
	document.location.href	=	document.location.href;
}
function openItem(nItemId)
{
	itemId	=	nItemId;
	var pageFrame = document.getElementById('itemIframe'); 
	
	pageFrame.src 	=	url+nItemId;
		
	$('#dialog-message').dialog('open');
	return false;
}
</script>

<script type="text/javascript">
	$(function(){
		// Dialog	( Start Edit Variant Popup Window Here )
		$('#dialog-message').dialog({
			autoOpen: false,
			modal: true,
			width: 560
		});

	});

	
</script>

<!-- End Menu Popups -->


<!-- Start Menu Popup -->
    <div id="dialog-message" title="Item Details">
        <iframe allowtransparency="true" frameborder="0" width="526" height="590" style="background:0px none; padding-top:10px;" id="itemIframe" name="itemIframe">
            <!--<script type="text/javascript">
                document.location = "<?=base_url()?>userrestaurant/additem";
            </script>
            <noscript>
                Your browser doesn't appear to support frames.  Please see the 
                <a href="<?=base_url()?>userrestaurant/additem">non-framed version</a> of this page.
            </noscript> 
            -->
        </iframe>
    </div>
<!-- End Menu Popup -->

    	<div class="crum-menu">
        	<a href="<?=base_url()?>">Home</a><span>&gt;</span>
            About Us
        </div>
		<div class="cont-wrap">
        	<div class="cont-round"><img src="<?=base_url()?>images/front/rest-top.jpg" alt="top" border="0" /></div>
        	<div class="rest-mid">

            <!-- Start Restaurant Head -->
				<div class="account-hed">
                	<h1>About Us</h1>
                </div>
            <!-- End Restaurant Head -->
				<br class="clear" />
			      <div class="ui-widget contentPage">
                        <p><br class="clear" /><br/>details</p>
                        
                    </div>

            </div>
        	<div class="cont-round"><img src="<?=base_url()?>images/front/rest-bottom.jpg" alt="top" border="0" /></div>
        </div>

<?
$this->load->view("userfront/footer_view");
?>
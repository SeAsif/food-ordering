<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href="<?=base_url()?>css/frontstyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

body { background:0px none !important;}

</style>
</head>

<body>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="legend">
  <tr>
    <td>
        <span class="takeout" title="Take Out">Take Out</span>
    </td>
  </tr>
  <tr>
    <td>
        <span class="dine-inn" title="Dine Inn">Dine In</span>
    </td>
  </tr>
  <tr>
    <td>
        <span class="proximity" title="Proximity to Gate">Proximity to Gate (45m)</span>
    </td>
  </tr>
  <tr>
    <td>
        <span class="pre-security" title="Pre-Security">Pre-Security</span>
    </td>
  </tr>
  <tr>
    <td>
        <span class="post-security" title="Pre-Security">Post-Security</span>
    </td>
  </tr>
</table>

</body>

</html>
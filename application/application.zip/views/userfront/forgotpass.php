

<!-- Start Error Success Msg -->
        <br/>
        <div class="ui-widget" id="error" style="display:none">
            <div class="ui-state-error ui-corner-all" style="padding:10px;"> 
			<strong>Alert:</strong> Username or password is invalid                
            </div>
            
        </div>
        <div class="ui-widget" id="error_guest" style="display:none">
            <div class="ui-state-error ui-corner-all" style="padding:10px;"> 
			<strong>Alert:</strong> Email addresses does not match                
            </div>
            
        </div>

        <br class="clear" />
<!-- End Error Success Msg -->


<form method="post" id="forgot-form">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="signin">
    <tr>
        <td style="vertical-align:top;">
            Email:
        </td>
        <td style="padding-left:10px;">
            <input name="user" id="user" type="text" class="signinfld" />
        </td>
    </tr>
    <tr>
        <td>
            
        </td>
        <td style="padding-left:10px;">
            <input name="forgot" id="forgot" type="submit" class="add-btn" value="Submit" style="float:left;" />
        </td>
    </tr>
</table>
</form>

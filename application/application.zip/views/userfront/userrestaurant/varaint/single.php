        <div class="extraWrap">
            <h1><?=$GroupDetail["group_name"]?>&nbsp;<?=($GroupDetail["required"]=="Yes")?"<span>(Required)</span>":""?></h1>
            <span style="color:#FF0000; display:block; float:left; padding-bottom:5px;">
				<?=isset($variantInfo["varianterrors"][$VariantNumber]) ? $variantInfo["varianterrors"][$VariantNumber] : ""?>
            </span>
            <div class="extraItem">
                    <input type="hidden" value="<?=$GroupDetail["required"]?>" name="variantrequired_<?=$VariantNumber?>" />
                    <input type="hidden" value="single" name="varianttype_<?=$VariantNumber?>" />                
                    <input type="hidden" value="<?=$GroupDetail["id"]?>" name="variantgroup_<?=$VariantNumber?>" />
					<?
                    foreach ($GroupDetail["variant"] as $varaintItem)
					{
					?>
						<div class="multi">
                        	<input type="radio" name="variant_name_<?=$VariantNumber?>" class="float-left radio" value="<?=$varaintItem["id"]?>" <?=isset($variantInfo["variantdata"][$VariantNumber]) && ($variantInfo["variantdata"][$VariantNumber]==$varaintItem["id"])?'checked="checked"':""?>/>
							<?=$varaintItem["name"]?>
                        </div>
                    <?
					}//end foreach ($GroupDetail["variant"] as $varaintItem)
					?>
            </div>
        </div>
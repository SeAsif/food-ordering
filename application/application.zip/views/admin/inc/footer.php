	
    </div>
<!-- End Admin Mid Wrap -->


</div>
<!-- End Admin Main Wrap -->


<!-- Start Footer -->
<div id="footer-wrap">
	Transit Grub 2010-2011, All Risghts Reserved
</div>
<!-- End Footer -->

</body>
</html>

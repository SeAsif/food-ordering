<html>
	<head>
		<link href="<?=base_url()?>css/style.css" rel="stylesheet" type="text/css">
        <link type="text/css" href="<?=base_url()?>css/cupertino/jquery-ui-1.8.6.custom.css" rel="stylesheet" />	
<script type="text/javascript" src="<?=base_url()?>js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery-ui-1.8.6.custom.min.js"></script>

        <!-- <script type="text/javascript" src="https://getfirebug.com/firebug-lite.js"></script> -->
	</head>
<body>
<!-- Start Admin Main Wrap -->
<div id="main-wrap">

<!-- Start Admin Header Wrap -->
	<div id="hed-wrap">
    	<div class="logo"><a href="<?=base_url()?>admin/dashboard">Transit Admin Management</a></div>
        <div class="login-wrap01">
            <span class="login"><a href="<?=base_url()?>admin/logout/" title="logout">Log Out</a></span>
        	<span class="login-name">
            	<strong><a href="<?=base_url()?>admin/dashboard">Home</a></strong>
            </span>
        </div>
    </div>
    <br class="clear" />
<!-- End Admin Header Wrap -->

<!-- Start Admin Mid Wrap -->
	<div id="mid-wrap">
	
<?
		$this->load->view( 'admin/header_view');

?>
<?=form_open_multipart(base_url().'admin/add_brand')?>
			<div class="trl-menu">
	<? 
	if(isset($breadcrumbs))
	{
			echo $breadcrumbs;
	}
	?>
                
            </div>
            <br class="clear" />
			<table align="center" cellpadding="5" cellspacing="1" class="tablebg">

				<tr>
					<td align="center" colspan="5" class="tdHead"><strong>Add Restaurant Brand</strong></td>
				</tr>
				<tr>
				  <td colspan="2" class="tdRow" style="color:#FF0000">
                  <div align="center">
					<?
					 if(isset($errors))  	
					 {
					   if (isset($errors) && count($errors) > 0)
					   {
						   foreach ($errors as $error)
						   {
							echo $error;
						   }
					   }
					 } 
					?>                                    
                  </div>                  </td>
			  </tr>
				

				<tr>
					<td align="left" class="tdRow" width="162">Restaurant Brand Name</td>
					<td width="404" align="left" class="tdRow">
					<input name="name" type="text" class="input" size="56" maxlength="255" value="<?=set_value('name');?>">					</td>
					<input type="hidden" name="hidden">
				</tr>
				<tr>
				  <td align="left" class="tdRow">Detail</td>
				  <td align="left" class="tdRow"><textarea name="detail" id="textarea" cols="35" rows="5"><?=set_value('detail');?></textarea></td>
			  </tr>
				
				<tr>
					<td align="center" class="tdRow"></td>
					<td align="center" class="tdRow">
							<input type="submit" class="btn" value="Submit" >
                    </td>
				</tr>
		</table>
</form>
<?
		$this->load->view( 'admin/footer_view');

?>
<?
		$this->load->view( 'admin/header_view');

?>
		<script>
			function Caution(variantID,name)
			{
				answer = window.confirm("Are you sure you want to delete "+name+" variant?");
				
				if(answer == true)
				{
					document.location="<?=base_url()?>admindefaultvariants/delete/"+variantID;
				}
			}
		</script>
			<div class="trl-menu">
	<? 
	if(isset($breadcrumbs))
	{
			echo $breadcrumbs;
	}
	?>
            </div>
            <br class="clear" />

		<table align="center" width="775" cellpadding="5" cellspacing="1">
			<tr>
				<td align="left" colspan="3">&nbsp;</td>
				<td width="571" colspan="2" align="right">
					<a href="<?=base_url()?>admindefaultvariants/edit" class="linkMain"
						onMouseOver="window.status='Add Terminal'; return true;"
						onMouseOut="window.status=''; return true;">Add Default Variant</a>				</td>
			</tr>
	</table>
		<table align="center" width="775" cellpadding="5" cellspacing="1" class="tablebg">
			<tr>
				<td align="center" colspan="6" class="tdHead"><strong>Manage Default Variants </strong></td>
			</tr>
			<tr>
				<td align="center" class="tdTitle" width="3%"></td>
				<td align="center" class="tdTitle">Variant Name</td>
				<td align="center" class="tdTitle">Price</td>                
				<td align="center" class="tdTitle">Status</td>                
				<td align="center" class="tdTitle" width="8%">Edit</td>
				<td align="center" class="tdTitle" width="9%">Delete</td>
			</tr>
			<?
			$count=0;
            foreach($list as $item)
			{
			?>			
			<tr>
                <td class='tdRow' align='center'><?=$item["id"]?></td>
                <td class='tdRow' align='center'><?=$item["name"]?></td>
                <td class='tdRow' align='center'><?=$item["price"]?></td>
                <td class='tdRow' align='center'><?=$item["status"]?></td>
                <td class='tdRow' align='center'>
                    <a href='<?=base_url()?>admindefaultvariants/edit/<?=$item["id"]?>' class='link'>Edit</a>
                </td>
                <td class='tdRow' align='center'>
                    <a href='javascript: Caution(<?=$item["id"]?> , "<?=$item["name"]?>");' class='link'>Delete</a>
                </td>
            </tr>
            <?
            }
			?>
		</table>
<?
		$this->load->view( 'admin/footer_view');
?>

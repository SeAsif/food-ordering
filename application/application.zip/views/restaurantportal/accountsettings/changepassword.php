<?
$this->load->view("restaurantportal/header_view");
$this->load->view("restaurantportal/sidepanel_view");
?>
<!-- Start Mid Right -->
		<div class="mid-right">
        	<h1>Change Password</h1>
            <?
            if (isset($success["msg"]))
			{
			?>
            <div class="ui-widget">
                <div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;"> 
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
                    <strong><?=$success["msg"]?></strong></p>
                </div>
            </div>
            <?
            }
			?>
            <?
            if (isset($errors) && count($errors))
			{
			?>
            <br/>
            <div class="ui-widget">
                <div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"> 
                	<?
                    foreach ($errors as $error)
					{
						echo $error;
					}
					?>
                    
                </div>
                
            </div>
            <?
            }
			?>
            <br class="clear" />
            <br />
			<?
            $attributes = array('id' => 'frmchangepassword','name' => 'frmchangepassword');
            echo form_open(base_url().'restaurantsettings/changepassword',$attributes);
            ?>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" class="password">
              <tr>
                <td style="width:20%;"><strong>Old Password:</strong></td>
                <td><input name="currentpassword" type="password" class="txt-field" /></td>
              </tr>
              <tr>
                <td><strong>New Password:</strong></td>
                <td><input name="Password" type="password" class="txt-field" /></td>
              </tr>
              <tr>
                <td><strong>Retype Password:</strong></td>
                <td><input name="ConfirmPassword" type="password" class="txt-field" /></td>
              </tr>
              <tr>
                <td></td>
                <td>
                	<input name="btm" type="image" src="<?=base_url()?>images/save.jpg" style="margin-right:10px;" />
                	<input name="btm1" type="image" src="<?=base_url()?>images/cancel.jpg" style="margin-right:10px;" />
                </td>
              </tr>
            </table>
            </form>
        </div>
<!-- End Mid Right -->
<?
$this->load->view("restaurantportal/footer_view");
?>
<?
$this->load->view("restaurantportal/header_view");
$this->load->view("restaurantportal/sidepanel_view");
?>

<script language="javascript">
var urladd	=	'<?=base_url()?>restaurantvariant/variantitems/';
function refreshItemPage(msg)
{
//refresh item page
//close item popup
	if (msg	==	"Added Successfully")
	{
		document.location.href	=urladd+"added";	
	}
	else
	{
		document.location.href	=urladd+"updated";	
	}
}

var variantItem;
var editVariant	;
var url	=	'<?=base_url()?>restaurantvariant/editvariant/';
function editVariants(nItemId)
{
	editVariant	=	nItemId;
	itemId	=	nItemId;
	var pageFrame = document.getElementById('variantitemIframe'); 
	
	pageFrame.src 	=	url+nItemId;
	
	$('#edit_food_variant').dialog('open');
	return false;
}

var viewVariant	;
var viewFrame	=	'<?=base_url()?>restaurantvariant/viewvariant/';
function viewVariants(nItemId)
{
	viewVariant	=	nItemId;

	var pageFrame = document.getElementById('variantitemviewIframe'); 
	
	pageFrame.src 	=	viewFrame+nItemId;

	$('#view_food_variant').dialog('open');
	return false;
}

var disableVariant	;

function disableVariants(nItemId, strvariantItem, type)
{
	if (type	==	undefined)
	{
		$('#disable_food_variant_text').html("Disable");
		disableType	=	"Inactive";
	}
	else
	{
		$('#disable_food_variant_text').html("Activate");
		disableType	=	"Active";
	}
	$('#newspan_variantName').html(strvariantItem);
	variantItem	=	strvariantItem;
	disableVariant	=	nItemId;
	$('#disable_food_variant').dialog('open');
	return false;
	
}

var deleteVariant	;
function deleteVariants(nItemId, strvariantItem)
{
	deleteVariant	=	nItemId;
	variantItem	=	strvariantItem;
	$('#span_variantName').html(strvariantItem);
	$('#delete_food_variant').dialog('open');
	return false;
}

</script>

<!-- Start Dialog Popups -->
<script type="text/javascript">
			$(function(){
				// Dialog	( Start Edit Variant Popup Window Here )
				$('#edit_food_variant').dialog({
					autoOpen: false,
					modal: true,
					width: 593,
				});

				// Dialog	( Start Edit Variant Popup Window Here )
				$('#view_food_variant').dialog({
					autoOpen: false,
					modal: true,
					width: 580,
				});

				// Dialog	( Start Disable Popup Window Here )
				$('#disable_food_variant').dialog({
					autoOpen: false,
					modal: true,
					width: 600,
					height: 180,
					buttons: {
						"Yes": function() { 
							
							$("#variantgroupname").val(variantItem);
							$("#updatestatus").val(disableType);
							$("#updateid").val(disableVariant);
							 
							document.statuschange.submit();
						
						}, 
						"No": function() { 
							$(this).dialog("close"); 
						} 
					}
				});

				// Dialog	( Start Delete Popup Window Here )
				$('#delete_food_variant').dialog({
					autoOpen: false,
					modal: true,
					width: 600,
					height: 180,
					buttons: {
						"Yes": function() { 
							$("#variantgroupname").val(variantItem);
							$("#updatestatus").val("Deleted");
							$("#updateid").val(deleteVariant);
							document.statuschange.submit();
						}, 
						"No": function() { 
							$(this).dialog("close"); 
						} 
					}
				});
				
				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); }, 
					function() { $(this).removeClass('ui-state-hover'); }
				);
				
			});
function closeAddVariant()
{
$('#edit_food_variant').dialog('close');
}
function closeViewVariant()
{
$('#view_food_variant').dialog('close');
}
			
		</script>
<!-- End Dialog Popups -->

                       <?
			echo form_open(base_url().'restaurantvariant/variantitems',array('id' => 'statuschange','name'=>'statuschange'));

?>            
            <input type="hidden" name="variantgroupname" id="variantgroupname" />
            <input type="hidden" name="updatestatus" id="updatestatus" />
            <input type="hidden" name="updateid" id="updateid" />
                    </form>
        <!-- Start Delete Popup Window Here -->

                       
                        <!-- Start Edit Variant Popup Window Here -->
                        <div id="edit_food_variant" title="Creat New Variant Or Edit Variant">
                        	<iframe allowtransparency="true" frameborder="0" width="580" height="486" style="background:0px none;" id="variantitemIframe"></iframe>
                        </div>
                        <!-- End Edit Variant Popup Window Here -->
                        
                        <!-- Start View Variant Popup Window Here -->
                        <div id="view_food_variant" title="View Variant Detail">
							<iframe allowtransparency="true" frameborder="0" width="553" height="151" style="background:0px none;" id="variantitemviewIframe"></iframe>
                        </div>
                        <!-- End View Variant Popup Window Here -->

                        <!-- Start Disable Popup Window Here -->
                        <div id="disable_food_variant" title="Disable Food Variant">
                        	<br />
							<span style="float: left; margin: 0pt 7px 10px 0pt;" class="ui-icon ui-icon-info"></span>
                            <strong>Are you want to <span id="disable_food_variant_text"></span> <span id="newspan_variantName"></span> food Variant</strong>
                        </div>
                        <!-- End Disable Popup Window Here -->

                        <!-- Start Delete Popup Window Here -->
                        <div id="delete_food_variant" title="Delete Food Variant">
                        	<br />
							<span style="float: left; margin: 0pt 7px 10px 0pt;" class="ui-icon ui-icon-info"></span>
                            <strong>Are you want to Delete <span id="span_variantName"></span> food Variant</strong>
                        </div>
                        <!-- End Delete Popup Window Here -->
<!-- Start Mid Right -->
		<div class="mid-right">
        	<h1>
            	Manage Food Variants
                <a href="javascript:void(null);" onclick="editVariants(0);" class="global-link float-right">
                <span>Add New Variant</span></a>
            </h1>
            <?
            if (isset($success["msg"]))
			{
			?>
            <div class="ui-widget">
                <div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;"> 
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
                    <strong><?=$success["msg"]?></strong></p>
                </div>
            </div>
            <?
            }
			?>
            <?
            if (isset($errors) && count($errors))
			{
			?>
            <br/>
            <div class="ui-widget">
                <div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"> 
                	<?
                    foreach ($errors as $error)
					{
						echo $error;
					}
					?>
                    
                </div>
                
            </div>
            <?
            }
			?>
            <br />
            <br class="clear" />
            <br/>
            <a href="<?=base_url()."restaurantvariant/variantitems"?>" <?=($activetab=="variantitems")?'class="creat-active"':'class="creat-ctgry"'?>>Current Food Variants (<?=$totalcount?>)</a>
            <a href="<?=base_url()."restaurantvariant/variantcategories"?>" <?=($activetab=="variantcategories")?'class="creat-active"':'class="creat-ctgry"'?>>Manage Variant Categories</a>
            <br class="clear" />
            <div class="variant-wrap">
                <div class="itemdrop-list" style="padding-top:20px;">
                <?
                //	$attributes	=	array("id"=>"frmAddItem","name"=>"frmAddItem")
                $attributes = array('id' => 'frmsearchitem','name' => 'frmsearchitem');
                echo form_open(base_url().'restaurantvariant/variantitems',$attributes);
                ?>
                
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td style="width:17%;">Within Category:</td>
                    <td>
                        <?=getFoodCategoryDropDown($categorylist,$filters["category_id"],'class="combwd01" style="width:200px;"')?>
                    </td>
                    <td>By Letter:</td>
                    <td>
                          <select name="alphabet" class="combwd01" style="width:56px;">
                            <option <?=($filters["alphabet"]=="")?'selected="selected"':''?> value="">All</option>
                            <?
                            for ($char=0;$char<26;$char++)
                            {
                                $val	=	chr($char+65);
                                $isSelected	=	($filters["alphabet"]	==	$val)?'selected="selected"':'';
                            ?>
                            <option value="<?=$val?>" <?=$isSelected?>><?=$val?></option>
                            <?
                            }
                            ?>
                            
                          </select>
                    </td>
                    <td>Show:</td>
                    <td>
                        <select name="status" class="combwd01">
                            <option value="All" <?=($filters["status"]=="All")?'selected="selected"':''?>>All</option>
                            <option value="Active" <?=($filters["status"]=="Active")?'selected="selected"':''?>>Active</option>
                            <option value="Inactive" <?=($filters["status"]=="Inactive")?'selected="selected"':''?>>Disable</option>
                        </select>
                        
                    </td>
                    <td style="width:75px;">
                        <a href="javascript:void(null);" onclick="document.frmsearchitem.submit();" class="global-link" style="float:right;"><span>Search</span></a>
                    </td>
                  </tr>
                </table>
                </form>
            </div>
                <div class="ctgry-table">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr class="ctgry-rowbg01">
                        <td style="width:7%;">No</td>
                        <td style="width:20%;">Variant Name</td>
                        <td align="center">Category</td>
                        <td align="center">Type</td>
                        <td style="width:45%;">Actions</td>
                      </tr>
                      <?
				  $nCount	=	$ncounter;
					  
                      foreach ($variants as $variant)
                      {
                      ?>
                      <tr class="<?=($variant["status"]	==	"Inactive")?'ctgry-disable':'ctgry-rowbg02'?>">
                        <td align="center"><?=$nCount?></td>
                        <td><?=$variant["group_name"]?></td>
                        <td align="center"><span><?=$variant["category_name"]?></span></td>
                        <td align="center"><span><?=$variant["selection"]?></span></td>
                        <td class="action">
                        <a href="javascript:void(null);" onclick="editVariants(<?=$variant["id"]?>);">Edit Variant</a><span>l</span>
                        <a href="javascript:void(null);" onclick="viewVariants(<?=$variant["id"]?>);">View Variant</a><span>l</span>
                        <?
						if ($variant["status"]	==	"Inactive")
						{
						?>
                        <a href="javascript:void(null);" onclick="disableVariants(<?=$variant["id"]?>,'<?=$variant["group_name"]?>','Activate');" class="disable-active">Activate</a><span>l</span>
                        <?
                        }
						else
						{
						?>
                        <a href="javascript:void(null);" onclick="disableVariants(<?=$variant["id"]?>,'<?=$variant["group_name"]?>');">Disable</a><span>l</span>
                        <?
						}
						?>
                        <a href="javascript:void(null);" onclick="deleteVariants(<?=$variant["id"]?>, '<?=$variant["group_name"]?>');">Delete</a>                    </td>
                      </tr>
                      <tr>
                        <td colspan="5" class="td-height"></td>
                      </tr>
                      <?
					  $nCount++;
                      }
                      ?>
                      <tr>
                        <td colspan="5" class="td-height"></td>
                      </tr>
                    </table>
              </div>
                <div class="paging">
                    <?=$paginationLinks?>
                </div>
            </div>
        </div>
<!-- End Mid Right -->
<?
$this->load->view("restaurantportal/footer_view");
?>
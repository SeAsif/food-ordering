
<link href="<?=base_url()?>css/style.css" rel="stylesheet" type="text/css" />
<link type="text/css" href="<?=base_url()?>css/cupertino/jquery-ui-1.8.6.custom.css" rel="stylesheet" />	

<style type="text/css">

body { background:0px none !important;}

</style>



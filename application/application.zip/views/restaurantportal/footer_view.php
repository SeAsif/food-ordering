    </div>
<!-- End Mid Section -->

</div>
<!-- End Main Body -->

<!-- Start Footer -->
<div id="footer-wrap">
	Transit Grub 2010-2011, All Rights Reserved.
</div>
<!-- End Footer -->

</body>
</html>

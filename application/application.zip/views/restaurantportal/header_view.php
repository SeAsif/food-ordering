<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Restaurant Management</title>
<link href="<?=base_url()?>css/style.css" rel="stylesheet" type="text/css" />

<!--.................menu..............-->
<script type="text/javascript" src="<?=base_url()?>js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/ddaccordion.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/menu.js"></script>
<link rel="stylesheet" href="<?=base_url()?>css/menu.css" type="text/css" />
<!--.................menu..............-->

<!--.................Variant Popup..............-->
<script type="text/javascript" src="<?=base_url()?>js/dropdowncontent.js"></script>
<!--.................Variant Popup..............-->

<!--................. Start Jquery Ui ..............-->
<link type="text/css" href="<?=base_url()?>css/cupertino/jquery-ui-1.8.6.custom.css" rel="stylesheet" />	
<script type="text/javascript" src="<?=base_url()?>js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/jquery-ui-1.8.6.custom.min.js"></script>

<script type="text/javascript">
	$(function() {
		
		var returnUrl	=	'';

		// run the currently selected effect
		function showSuccess(msg,url) {

			$( "#showMessageText" ).html(msg);
			
			returnUrl	=	url;
			// get effect type from 
			
			var selectedEffect = "bounce";

			// most effect types need no options passed by default
			var options = {};
			// some effects have required parameters
			if ( selectedEffect === "scale" ) {
				options = { percent: 100 };
			} else if ( selectedEffect === "size" ) {
				options = { to: { width: 280, height: 185 } };
			}

			// run the effect
			$( "#showMessage" ).show( selectedEffect, options, 500, callback );
		};

		//callback function to bring a hidden box back
		function callback() {
			setTimeout(function() {
				$( "#showMessage:visible" ).removeAttr( "style" ).fadeOut();
			}, 1000 );
		};
		
/*		function refreshMessage(showMsg)
		{
		
		}
*/
//		alert ('def');

		$( "#showMessage" ).hide();
		<?
		if (isset($success["msg"]))
		{
		?>
//			showSuccess("<?=$success["msg"]?>","<?=base_url()?>");
		<?
		}
		?>
	
	});
	
	

</script>
        
<!--................. End Jquery Ui ..............-->


<!--................. Start FireBud Here ..............-->
 <!-- <script type="text/javascript" src="https://getfirebug.com/firebug-lite.js"></script> -->
<!--................. End FireBud Here ..............-->

</head>

<body>
	<div id="showMessage" class="ui-widget-content ui-corner-all" style="display:none; visibility:hidden;">
		<h3 class="ui-widget-header ui-corner-all">Show</h3>
		<p id="showMessageText"></p>
	</div>
<!-- Start Main Body -->
<div id="main-wrap">

<!-- Start Header -->
	<div id="hed-wrap">
    	<div class="logo">
        	<a href="<?=base_url();?>">Restaurant Management</a>
        </div>
        <div class="login-wrap">
        <?
//			$login	=	$this->session->user_data();
			$restaurantArr = $this->session->userdata('restaurant');
//			print_r ($restaurantArr);

			$restaurantID	=	$restaurantArr["id"];

        	if ($restaurantID!="")
			{
		?>
            <span class="login"><a href="<?=base_url();?>restaurantsettings/logout" title="logout">Log Out</a></span>
        	<span class="login-name">Welcome <strong><?=$this->session->userdata('fullname')?></strong></span>
		<?
            }
			else
			{
		?>
            <span class="login"><a href="<?=base_url();?>restaurantportal" title="logout">Log In</a></span>        
        <?	
			}
		?>
        </div>
    </div>
<!-- End Header -->

<!-- Start Mid Section -->
	<div id="mid-wrap">

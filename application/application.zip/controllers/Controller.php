<?

class Controller extends CI_Controller {

}
